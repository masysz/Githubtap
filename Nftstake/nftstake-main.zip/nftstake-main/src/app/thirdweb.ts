'use client';

export { ThirdwebProvider, ConnectEmbed } from 'thirdweb/react';